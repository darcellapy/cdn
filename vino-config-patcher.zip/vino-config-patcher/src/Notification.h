#pragma once

void ShowNotification(const char * notification);

void StartNotificationThread(const char * value);

void StopNotificationThread();
