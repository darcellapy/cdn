// nova is real (I think)
// very very bad code probably
// I just took inkay (credit to pretendo), stripped a bunch of stuff, added and changed some stuff, and yeah ig

#include "main.hpp"

#include <wups.h>
#include <coreinit/cache.h>
#include <coreinit/dynload.h>
#include <coreinit/mcp.h>
#include <coreinit/memory.h>
#include <coreinit/memorymap.h>
#include <coreinit/memexpheap.h>
#include "Notification.cpp"
#include <notifications/notifications.h>
#include <optional>
#include <iostream>
#include <stdio.h>
#include <stdbool.h>
#include <cstdlib>

#include <thread>

#include "log.cpp"
#include "config.h"

WUPS_PLUGIN_NAME("Vino Config Patcher);
WUPS_PLUGIN_DESCRIPTION("LatteU TVii patcher");
WUPS_PLUGIN_VERSION("v1.0");
WUPS_PLUGIN_AUTHOR("Glitchii");
WUPS_PLUGIN_LICENSE("GPL");
WUPS_USE_STORAGE("vcp");

std::string installDir = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt";

std::string dumbPatch = "#ur0 is default
url0:https://davidsosa2022.github.io/Nintendo-TVii-Web/

# on/off debug print of client
CallbackDebugPrint:0

# add timestamp to debug print
AddTimeStampToDebugPrint:0

# 0/1 download whitelist with/without Verifying service-token
# 0 download the white-list without service-token on http-request-header
# 1 download the white-list with service-token on http-request-header
WhiteList_VerifyServiceToken:0

# 0/1 use whitelist cache on NAND
WhiteList_UseCache:0

# on/off javascript error print on console
# 0:off, 1:on
JavaScriptErrorPrintOnConsole:0

# on/off javascript error print on dialog
# 0:off, 1:on
JavaScriptErrorPrintOnDialog:0

# on/off console.log()[javascript] print on console
# 0:off, 1:on
ConsoleLogPrint:0

# 0/1/2  TV rendering style
# 0:Development (display DRC-screen with some debug information)
# 1:Demo        (display only DRC-screen at center)
# 2:Final       (display nothing)
TVStyle:2

#LoadUrl
# 0: Load from WhiteList (If not exist, load from url0.)
# 1: Load from url0
LoadUrl:1

# 0/1 FriendList Contains Temporary Friend and Requested Friend or not.
# 0:Not Contain
# 1:Contain
ContainTemporaryFriend:0

# 0/1 Reset Navi Forcus on Drag Event
# 0:Disable (don't reset on drag event)
# 1:Enable  (reset on drag event)
NaviResetOnDrag:0

# Enable Accelearted Compositing
# 0 : Disable
# 1 : Enable
EnableAc:1

# Enable Event Lock at Page Loading
# 0 : Disable
# 1 : Enable
EnableEventLock:1

# User Agent Setting
# UserAgent_String: Mozilla/5.0 (Nintendo WiiU) AppleWebKit/534.52 (KHTML, like Gecko) NX/2.2.0.8.21 vn/1.1.JP
# 0/1/2/3 WhiteList Setting.
# 0:None    (vino does not use white-list)
# 1:File    (vino uses white-list on file, path is written at 'WhiteList_Path')
# 2:Network (vino uses white-list on network, path is written at 'WhiteList_Path'. in this mode, white-list is downloaded with a paticular ssl certification for client and server.)
# 3:Release (vino uses the final environment by each region.)
WhiteList_Use:0
#WhiteList_Path:https://cdn.ecliipse.app/whitelist.txt

# Allow 'file:' and 'http:' scheme. Finally, it is set to 'Not Allow'
# 0:Not Allow
# 1:Allow
AllowDebugScheme:1

# LoadingIcon
# 0:Not Draw Icon at Pre-loading
# 1:Draw
PreLoadIconDraw:0

# LayoutColor RGB (0-255)

P_TouchEffectSBColorR:115
P_TouchEffectSBColorG:238
P_TouchEffectSBColorB:255
P_TouchEffectSWColorR:0
P_TouchEffectSWColorG:238
P_TouchEffectSWColorB:255

P_TouchEffectMBColorR:107
P_TouchEffectMBColorG:114
P_TouchEffectMBColorB:255
P_TouchEffectMWColorR:0
P_TouchEffectMWColorG:199
P_TouchEffectMWColorB:255

W_NodeFrameBColorR:72
W_NodeFrameBColorG:197
W_NodeFrameBColorB:255
W_NodeFrameWColorR:128
W_NodeFrameWColorG:219
W_NodeFrameWColorB:255
W_NodeFrameVTColorR:217
W_NodeFrameVTColorG:255
W_NodeFrameVTColorB:249
W_NodeFrameVBColorR:153
W_NodeFrameVBColorG:249
W_NodeFrameVBColorB:255

W_BaseBColorR:72
W_BaseBColorG:197
W_BaseBColorB:255
W_BaseWColorR:128
W_BaseWColorG:219
W_BaseWColorB:255
W_BaseVTColorR:217
W_BaseVTColorG:255
W_BaseVTColorB:249
W_BaseVBColorR:153
W_BaseVBColorG:249
W_BaseVBColorB:255

W_DecideWColorR:128
W_DecideWColorG:220
W_DecideWColorB:255
"

#include <kernel/kernel.h>
#include <mocha/mocha.h>

bool file_exists(const char *filename)
{
    FILE *fp = fopen(filename, "r");
    bool is_exist = false;
    if (fp != NULL)
    {
        is_exist = true;
        fclose(fp); // close the file
    }
    return is_exist;
}

static bool is555(MCP_SystemVersion version) {
    return (version.major == 5) && (version.minor == 5) && (version.patch >= 5);
}

INITIALIZE_PLUGIN() {
    WHBLogUdpInit();
    WHBLogCafeInit();
    Config::Init();
    auto res = Mocha_InitLibrary();
    if (res != MOCHA_RESULT_SUCCESS) {
        DEBUG_FUNCTION_LINE("Mocha init failed with code %d!", res);
        return;
    }
    if (NotificationModule_InitLibrary() != NOTIFICATION_MODULE_RESULT_SUCCESS) {
        DEBUG_FUNCTION_LINE("NotificationModule_InitLibrary failed");
    }
    //get os version
    MCP_SystemVersion os_version;
    int mcp = MCP_Open();
    int ret = MCP_GetSystemVersion(mcp, &os_version);
    if (ret < 0) {
        DEBUG_FUNCTION_LINE("getting system version failed (%d/%d)!", mcp, ret);
        os_version = (MCP_SystemVersion) {
                .major = 5, .minor = 5, .patch = 5, .region = 'E'
        };
    }
    DEBUG_FUNCTION_LINE("Running on %d.%d.%d%c",
        os_version.major, os_version.minor, os_version.patch, os_version.region
    );
    if (Config::connect_to_latte) {
        FILE* file  = fopen("installDir.c_str",  "r");
        
        {
            if (file = dumbPatch)
                DEBUG_FUNCTION_LINE("Vino config patched successfully.");
                StartNotificationThread("LatteU on!");
                return;
            else
                continue;
        }

        fclose(fp);

        char oldname[] = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt";
        char newname[] = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt.original";
   
        rename(oldname, newname);

        FILE* file  = fopen("installDir.c_str",  "w");
        
        fputs(dumbPatch, fp);

        fclose(fp);
        DEBUG_FUNCTION_LINE("Vino config patched successfully.");
        StartNotificationThread("LatteU on!");
    }
    else {
        char *filename = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt"
        {
            if (file_exists(filename))
                remove(filename);
            else
                continue;
        }
        DEBUG_FUNCTION_LINE("Vino config patch skipped.");
        StartNotificationThread("LatteU off!");
    }
    MCP_Close(mcp);
}

DEINITIALIZE_PLUGIN() {
    WHBLogUdpDeinit();
    Mocha_DeInitLibrary();
    NotificationModule_DeInitLibrary();
}

ON_APPLICATION_START() {
    WHBLogUdpInit();
    WHBLogCafeInit();
    DEBUG_FUNCTION_LINE("VCI: hihi\n");
        return;
    }
    if (!Config::connect_to_latte) {
        DEBUG_FUNCTION_LINE("VCI: Vino patch skipped.");
        return;
    }
    uint32_t base_addr, size;
    if (OSGetMemBound(OS_MEM2, &base_addr, &size)) {
        DEBUG_FUNCTION_LINE("VCI: OSGetMemBound failed!");
        return;
    }
    ();
}

ON_APPLICATION_ENDS() {
    DEBUG_FUNCTION_LINE("VCI: shutting down...\n");
    StopNotificationThread();
}