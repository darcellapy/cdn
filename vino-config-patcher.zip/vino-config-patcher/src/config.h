#ifndef LATTE_CONFIG_H
#define LATTE_CONFIG_H

class Config {
public:
    static void Init();

    // wups config items
    static bool connect_to_latte;

    // private stuff
    static bool need_relaunch;
};

#endif //LATTE_CONFIG_H
