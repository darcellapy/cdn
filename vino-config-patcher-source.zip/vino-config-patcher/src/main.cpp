// nova is real (I think)
// very very bad code
// I just took inkay (credit to pretendo), stripped a bunch of stuff, added and changed some stuff, and yeah ig

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <wups.h>
#include <optional>
#include <coreinit/cache.h>
#include <coreinit/dynload.h>
#include <coreinit/mcp.h>
#include <coreinit/memory.h>
#include <coreinit/memorymap.h>
#include <coreinit/memexpheap.h>
#include <notifications/notifications.h>
#include <utils/logger.h>
#include "config.h"
#include "Notification.h"

#include <coreinit/filesystem.h>
#include <cstring>
#include <string>

WUPS_PLUGIN_NAME("Vino Config Patcher");
WUPS_PLUGIN_DESCRIPTION("LatteU TVii patcher");
WUPS_PLUGIN_VERSION("v1.0");
WUPS_PLUGIN_AUTHOR("Glitchii & Pretendo contributors");
WUPS_PLUGIN_LICENSE("GPL");

WUPS_USE_WUT_DEVOPTAB(); 
WUPS_USE_STORAGE("vcp");

std::string configDir = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt";

std::string dumbPatch = "#ur0 is default\nurl0:https://davidsosa2022.github.io/Nintendo-TVii-Web/\n\m# on/off debug print of client\nCallbackDebugPrint:0\n\n# add timestamp to debug print\nAddTimeStampToDebugPrint:0\n\n# 0/1 download whitelist with/without Verifying service-token\n# 0 download the white-list without service-token on http-request-header\n# 1 download the white-list with service-token on http-request-header\nWhiteList_VerifyServiceToken:0\n\n# 0/1 use whitelist cache on NAND\nWhiteList_UseCache:0\n\n# on/off javascript error print on console\n# 0:off, 1:on\nJavaScriptErrorPrintOnConsole:0\n\n# on/off javascript error print on dialog\n# 0:off, 1:on\nJavaScriptErrorPrintOnDialog:0\n\n# on/off console.log()[javascript] print on console\n# 0:off, 1:on\nConsoleLogPrint:0\n\n# 0/1/2  TV rendering style\n# 0:Development (display DRC-screen with some debug information)\n# 1:Demo        (display only DRC-screen at center)\n# 2:Final       (display nothing)\nTVStyle:2\n\n#LoadUrl\n# 0: Load from WhiteList (If not exist, load from url0.)\n# 1: Load from url0\nLoadUrl:1\n\n# 0/1 FriendList Contains Temporary Friend and Requested Friend or not.\n# 0:Not Contain\n# 1:Contain\nContainTemporaryFriend:0\n\n# 0/1 Reset Navi Forcus on Drag Event\n# 0:Disable (don't reset on drag event)\n# 1:Enable  (reset on drag event)\nNaviResetOnDrag:0\n\n# Enable Accelearted Compositing\n# 0 : Disable\n# 1 : Enable\nEnableAc:1\n\n# Enable Event Lock at Page Loading\n# 0 : Disable\n# 1 : Enable\nEnableEventLock:1\n\n# User Agent Setting\n# UserAgent_String: Mozilla/5.0 (Nintendo WiiU) AppleWebKit/534.52 (KHTML, like Gecko) NX/2.2.0.8.21 vn/1.1.JP\n# 0/1/2/3 WhiteList Setting.\n# 0:None    (vino does not use white-list)\n# 1:File    (vino uses white-list on file, path is written at 'WhiteList_Path')\n# 2:Network (vino uses white-list on network, path is written at 'WhiteList_Path'. in this mode, white-list is downloaded with a paticular ssl certification for client and server.)\n# 3:Release (vino uses the final environment by each region.)\nWhiteList_Use:0\n#WhiteList_Path:https://cdn.ecliipse.app/whitelist.txt\n\n# Allow 'file:' and 'http:' scheme. Finally, it is set to 'Not Allow'\n# 0:Not Allow\n# 1:Allow\nAllowDebugScheme:1\n\n# LoadingIcon\n# 0:Not Draw Icon at Pre-loading\n# 1:Draw\nPreLoadIconDraw:0\n\n# LayoutColor RGB (0-255)\n\nP_TouchEffectSBColorR:115\nP_TouchEffectSBColorG:238\nP_TouchEffectSBColorB:255\nP_TouchEffectSWColorR:0\nP_TouchEffectSWColorG:238\nP_TouchEffectSWColorB:255\n\nP_TouchEffectMBColorR:107\nP_TouchEffectMBColorG:114\nP_TouchEffectMBColorB:255\nP_TouchEffectMWColorR:0\nP_TouchEffectMWColorG:199\nP_TouchEffectMWColorB:255\n\nW_NodeFrameBColorR:72\nW_NodeFrameBColorG:197\nW_NodeFrameBColorB:255\nW_NodeFrameWColorR:128\nW_NodeFrameWColorG:219\nW_NodeFrameWColorB:255\nW_NodeFrameVTColorR:217\nW_NodeFrameVTColorG:255\nW_NodeFrameVTColorB:249\nW_NodeFrameVBColorR:153\nW_NodeFrameVBColorG:249\nW_NodeFrameVBColorB:255\n\nW_BaseBColorR:72\nW_BaseBColorG:197\nW_BaseBColorB:255\nW_BaseWColorR:128\nW_BaseWColorG:219\nW_BaseWColorB:255\nW_BaseVTColorR:217\nW_BaseVTColorG:255\nW_BaseVTColorB:249\nW_BaseVBColorR:150\nW_BaseVBColorG:249\nW_BaseVBColorB:255\n\nW_DecideWColorR:128\nW_DecideWColorG:220\nW_DecideWColorB:255";

INITIALIZE_PLUGIN() {
    WHBLogUdpInit();
    WHBLogCafeInit();
    Config::Init();

    if (NotificationModule_InitLibrary() != NOTIFICATION_MODULE_RESULT_SUCCESS) {
        DEBUG_FUNCTION_LINE("NotificationModule_InitLibrary failed");
    }
    
    if (Config::connect_to_latte) {
        FILE* file  = fopen(configDir.c_str(),  "w+");
        
        fputs(dumbPatch.c_str(), file);

        fclose(file);
        DEBUG_FUNCTION_LINE("Vino config patched successfully.");
        StartNotificationThread("LatteU on!");
    }
    else {
        char *filename = "/storage_mlc/sys/title/00050030/1001310a/content/vino_config.txt";
        remove(filename);
        DEBUG_FUNCTION_LINE("Vino config patch disabled.");
        StartNotificationThread("LatteU off!");
    }
}

DEINITIALIZE_PLUGIN() {
    WHBLogUdpDeinit();
    NotificationModule_DeInitLibrary();
}

ON_APPLICATION_START() {
    WHBLogUdpInit();
    WHBLogCafeInit();
    DEBUG_FUNCTION_LINE("VCI: hihi\n");
    if (!Config::connect_to_latte) {
        DEBUG_FUNCTION_LINE("VCI: Vino patch skipped.");
        return;
    }
    uint32_t base_addr, size;
    if (OSGetMemBound(OS_MEM2, &base_addr, &size)) {
        DEBUG_FUNCTION_LINE("VCI: OSGetMemBound failed!");
        return;
    }
  
}

ON_APPLICATION_ENDS() {
    DEBUG_FUNCTION_LINE("VCI: shutting down...\n");
    StopNotificationThread();
}